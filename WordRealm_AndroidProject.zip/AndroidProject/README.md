# WordRealm 词境背单词 —— Android 打包工程

## 📦 项目结构
```
WordRealm/AndroidProject/
├── settings.gradle
├── build.gradle
├── gradle.properties          ← 签名信息在这里改
├── keystore/                  ← 放你的签名文件 wordrealm.keystore
└── app/
    ├── build.gradle           ← 包名 / 版本号在这里改
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/wordrealm/app/MainActivity.java
        ├── assets/www/index.html   ← ★ 把 ../index.html 复制到这里 ★
        └── res/
            ├── values/{strings,themes}.xml
            ├── drawable/ic_launcher.xml
            └── mipmap-anydpi-v26/ic_launcher.xml
```

## 🚀 打包出 APK（三步）

### 第 0 步：复制网页文件
把 `Download/WordRealm/index.html` 复制到
`app/src/main/assets/www/index.html`
（assets/www 目录不存在就手动新建）

### 第 1 步：生成签名密钥（只需一次）
安装 JDK 后在终端执行：
```bash
keytool -genkeypair -v \
  -keystore keystore/wordrealm.keystore \
  -alias wordrealm \
  -keyalg RSA -keysize 2048 -validity 36500 \
  -storepass wordrealm123 -keypass wordrealm123 \
  -dname "CN=WordRealm, OU=Dev, O=You, L=City, ST=State, C=CN"
```
⚠️ 密钥文件和密码务必永久保存！上架后更新版本必须用同一个签名。

### 第 2 步：构建 APK
用 Android Studio：
- Open → 选择 `AndroidProject` 文件夹 → 等 Gradle 同步完成
- 菜单 Build → Generate Signed App Bundle / APK → APK → 选密钥 → release → Finish

或命令行：
```bash
cd AndroidProject
./gradlew assembleRelease
# 输出： app/build/outputs/apk/release/app-release.apk
```

### 第 3 步：（可选）转 AAB 上架 Google Play
```bash
./gradlew bundleRelease
# 输出： app/build/outputs/bundle/release/app-release.aab
```

## 🏪 各商店上架要求速查

| 商店 | 需要的材料 |
|---|---|
| 华为 AppGallery | 开发者账号 + 软著(个人可用承诺函) + APK/AAB + 隐私政策网址 + 截图4~5张 |
| 小米商店 | 个人开发者可上架 + 隐私政策 + 权限说明 |
| OPPO/vivo | 个人开发者 + 隐私政策 + 截图 + 权限用途说明 |
| 应用宝 | 个人开发者 + 软著较严格，建议先发其他店 |
| Google Play | $25 注册费 + AAB + 隐私政策 + 数据安全表单 |

**隐私政策模板要点**（必须提供，各商店都查）：
> 本应用不收集任何个人信息。词库、设置仅保存在您设备本地；如使用 AI 功能，
> 您填写的 API Key 仅用于向您自己指定的服务器发起请求；应用请求存储权限
> 仅用于导入本地 txt 词书文件。

## ⚠️ 注意事项
1. **versionCode 每次上架更新必须 +1**（app/build.gradle）
2. **签名文件丢了就无法更新应用**，务必备份
3. WebView 加载的是 file:// 协议，若某商店审核提示「使用已废弃协议」，
   可改为 WebViewAssetLoader（需要时告诉我帮你改造）
4. 首次打开若 AI 连不上，检查手机网络与 API 站点是否允许跨域